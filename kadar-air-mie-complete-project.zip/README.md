# Kadar Air Mie

Aplikasi pencatatan kadar air mie, perhitungan otomatis, pengaturan standar per kode produk, riwayat lokal, dan ekspor PDF.

## Jalankan di komputer
1. Install Node.js (versi LTS).
2. Extract proyek.
3. Buka terminal di folder proyek.
4. Jalankan:
   ```bash
   npm install
   npm run dev
   ```
5. Buka URL lokal yang ditampilkan Vite.

## Build web
```bash
npm install
npm run build
```

## Build APK melalui GitHub Actions
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini.
3. Buka tab **Actions**.
4. Pilih workflow **Build Android APK** lalu klik **Run workflow** (atau push ke branch main).
5. Tunggu workflow selesai.
6. Download artifact **Kadar-Air-Mie-debug-apk** dari halaman workflow.

Workflow membangun APK debug untuk instalasi dan pengujian. APK debug bukan APK Play Store release.

## Fitur
- Input beberapa sampel per sesi.
- Kadar air otomatis: `(berat kosong + berat sampel - berat kering bersama botol) / berat sampel × 100`.
- Standar minimum/maksimum per kode mie.
- Status sesuai/tidak sesuai.
- Riwayat pengujian tersimpan di perangkat/browser.
- Ekspor PDF.
- Offline setelah aplikasi dipasang.

## Catatan
Data disimpan lokal di perangkat/browser. Belum ada sinkronisasi antar HP atau akun cloud. Backup/ekspor PDF disarankan secara berkala.

## Branding assets
- `public/assets/app-icon.png`: app icon/logo image used in the header.
- `public/assets/branding-showcase.png`: branding and UI showcase artwork.
