import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import { Capacitor } from '@capacitor/core'
import { Filesystem, Directory } from '@capacitor/filesystem'
import { Share } from '@capacitor/share'
import './style.css'

const STORE = 'kadar-air-mie-v1'
const defaultStandards = { SKGA:{min:0,max:13}, IHAG:{min:0,max:12}, GS:{min:0,max:14}, KBGN:{min:0,max:13}, RBS:{min:0,max:11}, ICG:{min:0,max:12} }
const todayLocal = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` }
const emptySample = (n=1) => ({ id: crypto.randomUUID(), code:'', line:String(n), bottle:'', empty:'', sample:'', dryBottle:'' })
const fmt = (n, digits=4) => Number(n).toLocaleString('id-ID',{minimumFractionDigits:digits,maximumFractionDigits:digits})
const bottleNumber = s => { const n=Number(String(s.bottle||'').replace(',','.')); return String(s.bottle||'').trim()!==''&&Number.isFinite(n)?n:Infinity }
const sortSamples = list => [...list].sort((a,b)=>{const an=bottleNumber(a),bn=bottleNumber(b);if(an===bn)return 0;if(an===Infinity)return 1;if(bn===Infinity)return -1;return an-bn})
const calc = s => {
  if ([s.empty,s.sample,s.dryBottle].some(v=>v==='' || !Number.isFinite(Number(String(v).replace(',','.')))) || Number(String(s.sample).replace(',','.'))<=0) return null
  const empty=Number(String(s.empty).replace(',','.')), sample=Number(String(s.sample).replace(',','.')), dry=Number(String(s.dryBottle).replace(',','.'))
  return ((empty+sample-dry)/sample)*100
}
function getStatus(value, standard) {
  if (value===null || value===undefined || !standard) return 'Belum ada standar'
  return value >= Number(standard.min) && value <= Number(standard.max) ? 'Sesuai' : 'Tidak sesuai'
}
const readStore=()=>{try{return JSON.parse(localStorage.getItem(STORE)||'{}')}catch{return {}}}
function App(){
  const initial=readStore()
  const [page,setPage]=useState('dashboard')
  const [samples,setSamples]=useState(initial.draft?.samples?.length?initial.draft.samples:[emptySample()])
  const [date,setDate]=useState(initial.draft?.date||todayLocal())
  const [operator,setOperator]=useState(initial.draft?.operator||'')
  const [standards,setStandards]=useState(initial.standards||defaultStandards)
  const [newCode,setNewCode]=useState('')
  const [history,setHistory]=useState(initial.history||[])
  const [procedure,setProcedure]=useState(initial.procedure||{tools:'',materials:'',steps:''})
  const [deletedAutoDates,setDeletedAutoDates]=useState(initial.deletedAutoDates||[])
  const [savedAt,setSavedAt]=useState('')
  const update=(id,key,value)=>setSamples(prev=>prev.map(s=>s.id===id?{...s,[key]:value}:s))
  const addSample=()=>setSamples(prev=>[...prev,emptySample(prev.length+1)])
  const removeSample=id=>setSamples(prev=>prev.filter(s=>s.id!==id))
  const completed=samples.filter(s=>calc(s)!==null)
  const updateStandard=(code,key,value)=>setStandards(prev=>({...prev,[code]:{...prev[code],[key]:value}}))
  const addCode=()=>{const c=newCode.trim().toUpperCase();if(!c||standards[c])return;setStandards(prev=>({...prev,[c]:{min:0,max:0}}));setNewCode('')}
  const dailySession=()=>({id:`auto-${date}`,date,operator,created:new Date().toISOString(),auto:true,samples:sortSamples(samples).map(s=>({...s,water:calc(s),standard:{...(standards[s.code]||{})},status:getStatus(calc(s),standards[s.code])}))})
  // Autosave current work and create/update a single daily history record without pressing Save.
  useEffect(()=>{
    const draft={date,operator,samples}
    setHistory(prev=>{
      const id=`auto-${date}`
      const hasInput=operator.trim()!=='' || samples.some(s=>[s.code,s.bottle,s.empty,s.sample,s.dryBottle].some(v=>String(v||'').trim()!==''))
      if(deletedAutoDates.includes(date) || !hasInput) return prev.filter(h=>h.id!==id)
      const entry=dailySession(); const idx=prev.findIndex(h=>h.id===entry.id)
      if(idx<0) return [entry,...prev]
      const next=[...prev]; next[idx]=entry; return next
    })
    localStorage.setItem(STORE,JSON.stringify({standards,history,operator,draft,procedure,deletedAutoDates}))
    setSavedAt(new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit',second:'2-digit'}))
  },[date,operator,samples,standards,procedure,deletedAutoDates])
  // Persist history changes after the autosave effect updates it.
  useEffect(()=>{localStorage.setItem(STORE,JSON.stringify({standards,history,operator,draft:{date,operator,samples},procedure,deletedAutoDates}))},[history])
  const saveSession=()=>{if(!completed.length){alert('Isi minimal satu sampel lengkap terlebih dahulu.');return}setDeletedAutoDates(prev=>prev.filter(d=>d!==date));alert('Data pengujian sudah tersimpan otomatis di riwayat tanggal '+date+'.')}
  const exportPDF=async (session=null)=>{
    const list=sortSamples(session?.samples||completed.map(s=>({...s,water:calc(s),standard:standards[s.code]||null,status:getStatus(calc(s),standards[s.code])}))).filter(s=>s.water!==null)
    if(!list.length){alert('Belum ada sampel lengkap untuk dibuat PDF.');return}
    const doc=new jsPDF({orientation:'landscape',unit:'mm',format:'a4'})
    doc.setFontSize(16);doc.text('LAPORAN HASIL PENGUJIAN KADAR AIR MIE',148,14,{align:'center'})
    doc.setFontSize(10);doc.text(`Tanggal: ${session?.date||date}    Penguji: ${session?.operator||operator||'-'}`,14,22)
    const rows=list.map((s,i)=>[i+1,s.code||'-',s.line||'-',s.bottle||'-',s.empty||'-',s.sample||'-',s.dryBottle||'-',s.water==null?'-':fmt(s.water,2)+'%',s.standard?`${s.standard.min}% - ${s.standard.max}%`:'-',s.status||getStatus(s.water,s.standard)])
    autoTable(doc,{startY:27,head:[['No','Kode Mie','Line','No. Botol','Berat Kosong (g)','Berat Sampel (g)','Sampel Kering + Botol (g)','Kadar Air','Standar','Status']],body:rows,styles:{fontSize:8,cellPadding:2},headStyles:{fillColor:[15,118,110]},didParseCell:(data)=>{if(data.section==='body'&&data.column.index===9){const status=data.cell.raw;if(status==='Sesuai')data.cell.styles.textColor=[20,130,55];if(status==='Tidak sesuai')data.cell.styles.textColor=[190,35,45]}}})
    const name=`Kadar-Air-${session?.date||date}.pdf`, blob=doc.output('blob')
    try{if(Capacitor.isNativePlatform()){const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(reader.error||new Error('Gagal membaca PDF'));reader.readAsDataURL(blob)});const saved=await Filesystem.writeFile({path:name,data:base64,directory:Directory.Documents});await Share.share({title:'Laporan Kadar Air Mie',text:'Laporan hasil pengujian kadar air mie',files:[saved.uri],url:saved.uri,dialogTitle:'Bagikan laporan PDF'})}else{const file=new File([blob],name,{type:'application/pdf'});if(navigator.share&&navigator.canShare?.({files:[file]})){await navigator.share({title:'Laporan Kadar Air Mie',files:[file]})}else{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000)}}}catch(error){alert('Gagal membuat atau membagikan PDF: '+(error?.message||error))}
  }
  const removeHistory=id=>{const item=history.find(h=>h.id===id);if(item?.auto)setDeletedAutoDates(prev=>[...new Set([...prev,item.date])]);setHistory(h=>h.filter(x=>x.id!==id))}
  const nav=[['dashboard','Dashboard'],['input','Kadar Air'],['standards','Standar'],['history','Riwayat']]
  return <div className="app">
    <header><div className="brand"><div className="logo"><img src="/assets/app-icon.png" alt="Logo Kadar Air Mie" /></div><div><h1>Kadar Air Mie</h1><small>Laboratory sample recorder</small></div></div><button className="procedure-top" onClick={()=>setPage('procedure')}>☷ Prosedur Kerja</button></header>
    <nav>{nav.map(([p,label])=><button className={page===p?'active':''} onClick={()=>setPage(p)} key={p}>{label}</button>)}</nav>
    {page==='dashboard'&&<main><section className="dashboard-hero panel"><small>LABORATORY ANALYSIS</small><h2>Dashboard Pengujian</h2><p>Pilih jenis pengujian yang ingin kamu lakukan.</p></section><div className="module-grid"><button className="module-card active-module" onClick={()=>setPage('input')}><span className="module-icon">💧</span><strong>Kadar Air</strong><small>Perhitungan otomatis, standar, riwayat & PDF</small><span className="module-cta">Buka pengujian →</span></button>{[['FFA','Free Fatty Acid'],['AV','Acid Value'],['Kadar Lemak','Fat Content'],['Alkali','Alkali Analysis']].map(([name,desc])=><div className="module-card future-module" key={name}><span className="module-icon">🧪</span><strong>{name}</strong><small>{desc}</small><span className="module-cta muted">Segera tersedia</span></div>)}</div></main>}
    {page==='input'&&<main><section className="panel"><h2>Informasi Pengujian</h2><div className="formgrid"><label>Tanggal<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><label>Nama Penguji<input placeholder="Nama penguji" value={operator} onChange={e=>setOperator(e.target.value)}/></label></div><small className="autosave-note">✓ Tersimpan otomatis{savedAt?` · ${savedAt}`:''}</small></section>
      <div className="section-head"><h2>Data Sampel <span className="count">{samples.length}</span></h2><button className="primary" onClick={addSample}>＋ Tambah sampel</button></div>
      {sortSamples(samples).map((s,i)=>{const result=calc(s),standard=standards[s.code],status=getStatus(result,standard);return <section className="sample panel" key={s.id}><div className="sample-head"><h3>Sampel {i+1}</h3>{samples.length>1&&<button className="danger-text" onClick={()=>removeSample(s.id)}>Hapus</button>}</div><div className="formgrid three"><label>Kode Mie<input placeholder="Contoh: SKGA" value={s.code} onChange={e=>update(s.id,'code',e.target.value.toUpperCase())}/></label><label>Line Mesin<input inputMode="numeric" placeholder="1" value={s.line} onChange={e=>update(s.id,'line',e.target.value)}/></label><label>No. Botol Timbang<input inputMode="numeric" placeholder="14" value={s.bottle} onChange={e=>update(s.id,'bottle',e.target.value)}/></label></div><div className="formgrid three"><label>Berat Kosong (g)<input inputMode="decimal" placeholder="42,3423" value={s.empty} onChange={e=>update(s.id,'empty',e.target.value.replace(',','.'))}/></label><label>Berat Sampel (g)<input inputMode="decimal" placeholder="3,4334" value={s.sample} onChange={e=>update(s.id,'sample',e.target.value.replace(',','.'))}/></label><label>Berat Kering + Botol (g)<input inputMode="decimal" placeholder="44,9917" value={s.dryBottle} onChange={e=>update(s.id,'dryBottle',e.target.value.replace(',','.'))}/></label></div><div className={`result ${result===null?'incomplete':status==='Sesuai'?'good':'bad'}`}><div><small>KADAR AIR</small><strong>{result===null?'—':fmt(result,2)+'%'}</strong></div><div className="status">{result===null?'Lengkapi data':status==='Sesuai'?'✓ Sesuai standar':'! Tidak sesuai'}</div>{standard&&<small>Standar: {standard.min}% – {standard.max}%</small>}</div></section>})}
      <div className="actions"><button className="secondary" onClick={saveSession}>✓ Tersimpan otomatis</button><button className="primary" onClick={()=>exportPDF()}>⇩ Buat PDF</button></div><footer>Perhitungan: (Berat kosong + Berat sampel − Berat kering bersama botol) ÷ Berat sampel × 100%</footer></main>}
    {page==='standards'&&<main><section className="panel"><h2>Pengaturan Standar Kadar Air</h2><p className="muted">Atur rentang kadar air untuk setiap kode mie. Hasil pengujian akan otomatis dinilai.</p><div className="add-code"><input placeholder="Kode mie baru" value={newCode} onChange={e=>setNewCode(e.target.value)}/><button className="primary" onClick={addCode}>Tambah kode</button></div>{Object.entries(standards).map(([code,st])=><div className="standard-row" key={code}><strong>{code}</strong><label>Min (%)<input type="number" step="0.01" value={st.min} onChange={e=>updateStandard(code,'min',e.target.value)}/></label><label>Max (%)<input type="number" step="0.01" value={st.max} onChange={e=>updateStandard(code,'max',e.target.value)}/></label><button className="danger-text" onClick={()=>setStandards(prev=>{const n={...prev};delete n[code];return n})}>Hapus</button></div>)}</section></main>}
    {page==='history'&&<main><section className="panel"><h2>Riwayat Pengujian</h2>{!history.length?<p className="muted">Data pengujian akan tersimpan otomatis saat kamu mengisi sampel.</p>:history.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(h=><div className="history-card" key={h.id}><div><strong>{h.date}</strong><small>{h.operator||'Penguji tidak diisi'} · {h.samples.length} sampel{h.auto?' · Autosave':''}</small></div><div className="history-actions"><button className="secondary small" onClick={()=>exportPDF(h)}>PDF</button><button className="danger-text" onClick={()=>removeHistory(h.id)}>Hapus</button></div><div className="history-samples">{sortSamples(h.samples).map((s,i)=><span key={s.id||i} className={s.status==='Sesuai'?'chip-good':s.status==='Tidak sesuai'?'chip-bad':'chip-neutral'}>{s.bottle||'—'} · {s.code||'—'} {s.water==null?'Belum lengkap':Number(s.water).toFixed(2)+'%'}</span>)}</div></div>)}</section></main>}
    {page==='procedure'&&<main><section className="panel"><h2>Prosedur Kerja</h2><p className="muted">Isi dan simpan prosedur pengujian kadar air. Data ini tersimpan otomatis di perangkat.</p><label>Alat<textarea rows="4" placeholder="Tuliskan alat yang digunakan..." value={procedure.tools} onChange={e=>setProcedure(p=>({...p,tools:e.target.value}))}/></label><label>Bahan<textarea rows="4" placeholder="Tuliskan bahan yang digunakan..." value={procedure.materials} onChange={e=>setProcedure(p=>({...p,materials:e.target.value}))}/></label><label>Prosedur<textarea rows="8" placeholder="Tuliskan langkah-langkah kerja..." value={procedure.steps} onChange={e=>setProcedure(p=>({...p,steps:e.target.value}))}/></label><div className="autosave-note">✓ Prosedur tersimpan otomatis</div></section></main>}
  </div>
}
createRoot(document.getElementById('root')).render(<App/>)
